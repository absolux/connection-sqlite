
import { Connection, Query } from './types'

const REPLACE_FIELD_RE = /@([^\s]+)/g

const { isArray } = Array

export interface SQLiteDatabase {
  all (sql: string, params: object, cb: (err: any, rows: any[]) => void): any
}

export class SQLiteConnection implements Connection {
  /**
   * The SQLite3 database object
   */
  private _sqlite: SQLiteDatabase

  /**
   * 
   * @param db The SQLite3 database object
   */
  public constructor (db: SQLiteDatabase) {
    this._sqlite = db
  }

  /**
   * Execute a database query.
   *
   * @param obj The query object.
   * @param options Additional options.
   */
  public execute (obj: Query, options?: object): Promise<any[]> {
    let [sql, params] = this._normalize(obj)

    return new Promise<any[]>((resolve, reject) => {
      this._sqlite.all(sql, params, (err, result) => {
        err ? reject(err) : resolve(result)
      })
    })
  }

  /**
   * Normalize the query object.
   * 
   * @param query The query object.
   * @private
   */
  private _normalize ({ sql, params = [] }: Query): [string, any[]] {
    if (isArray(params)) return [sql, params]

    let arr: any[] = []

    sql = sql.replace(REPLACE_FIELD_RE, (_, field) => {
      let value = (params as any)[field]
      let i = arr.indexOf(value)

      return '?' + (i !== -1 ? i + 1 : (arr.push(value), ''))
    })

    return [sql, arr]
  }
}
