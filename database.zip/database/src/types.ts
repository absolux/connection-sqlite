
// import { Readable } from 'stream'

/**
 * The SQL query object
 */
export interface Query {
  params?: object
  sql: string
}

/**
 * Database connection adapter
 */
export interface Connection {
  /**
   * Execute a database query
   * 
   * @param obj The query object
   * @param options Additional options
   */
  execute (obj: Query, options?: object): Promise<any>
}
