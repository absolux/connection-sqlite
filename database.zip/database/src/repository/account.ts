
import { RepositoryError } from './error'
import { Connection, Query } from '../types'

export interface CreateAccountData {
  company: any
  name: string
  user: any
}

export interface UpdateAccountData {
  name: string
  id: any
}

export class AccountRepository {
  private _connection: Connection

  public constructor (db: Connection) {
    this._connection = db
  }

  public fetch (params: { company: any }) {
    let sql = `
      SELECT *
      FROM accounts
      WHERE company_id = @company
    `

    return this._execute({ sql, params })
  }

  public find (params: { id: any, company: any }) {
    let sql = `
      SELECT *
      FROM accounts
      WHERE company_id = @company and _id = @id
    `

    return this._execute({ sql, params })
  }

  public create (params: CreateAccountData) {
    Object.assign(params, { creation: new Date().toISOString() })

    let sql = `
      INSERT INTO accounts (name, author_id, company_id, created_at, modified_at)
      VALUES (@name, @user, @company, @creation, @creation)
      RETURNING *
    `

    return this._execute({ sql, params })
  }

  public update (params: CreateAccountData) {
    Object.assign(params, { modification: new Date().toISOString() })

    let sql = `
      UPDATE accounts
      SET name = @name, modified_at = @modification
      WHERE _id = @id and company_id = @company
      RETURNING *
    `

    return this._execute({ sql, params })
  }

  private _execute (q: Query) {
    return this._connection.execute(q).catch((err) => {
      throw new RepositoryError(err.message)
    })
  }
}
