
import { RepositoryError } from './error'
import { Connection, Query } from '../types'

export interface CreateData {
  company: number
  title: string
  user: number
}

export interface UpdateData {
  company: number
  title: string
  id: number
}

export interface FetchData {
  company: number
}

export class AccountRepository {
  private _connection: Connection

  public constructor (db: Connection) {
    this._connection = db
  }

  public fetch (params: FetchData) {
    let sql = `
      SELECT *
      FROM accounts
      WHERE company_id = @company
    `

    return this._execute({ sql, params })
  }

  public fetchWithBalance (params: FetchData) {
    let sql = `
      SELECT a.*, b.total_income, c.total_expense
      FROM accounts a
        LEFT JOIN (
          SELECT account_to, SUM(local_amount) total_income
          FROM payments
          WHERE company_id = @company
          GROUP BY account_to
        ) b ON (a._id = b.account_to)
        LEFT JOIN (
          SELECT account_from, SUM(local_amount) total_expense
          FROM payments
          WHERE company_id = @company
          GROUP BY account_from
        ) c ON (a._id = c.account_from)
      WHERE company_id = @company
    `

    return this._execute({ sql, params })
  }

  // public fetchWithPayments (params: { company: number, account: number }) {}

  public create (params: CreateData) {
    Object.assign(params, { creation: new Date() })

    let sql = `
      INSERT INTO accounts (title, company_id, creator_id, created_at)
      VALUES (@title, @user, @company, @creation::timestampz)
      RETURNING *
    `

    return this._execute({ sql, params })
  }

  // public update (params: UpdateData) {
  //   Object.assign(params, { modification: new Date() }) //.toISOString()

  //   let sql = `
  //     UPDATE accounts
  //     SET title = @title, modified_at = @modification
  //     WHERE _id = @id and company_id = @company
  //     RETURNING *
  //   `

  //   return this._execute({ sql, params })
  // }

  private _execute (q: Query) {
    return this._connection.execute(q).catch((err: Error) => {
      throw new RepositoryError(err.message)
    })
  }
}
