
export class RepositoryError extends Error {
  
}
