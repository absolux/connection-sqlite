
import { RepositoryError } from './error'
import { Connection, Query } from '../types'

export interface CreateData {
  accountFrom?: number | null
  accountTo?: number | null
  currency: string
  creation?: Date
  company: number
  amount: number
  title: string
  user: number
  date: Date
}

export class IncomeRepository {
  private _connection: Connection

  public constructor (db: Connection) {
    this._connection = db
  }

  public create (params: CreateData) {
    params = { accountTo: null, accountFrom: null,  ...params, creation: new Date() } //.toISOString()

    let sql = `
      INSERT INTO payments (
        title, date, company_id, account_to, account_from,
        local_amount, local_currency, creator_id, created_at
      )
      VALUES (
        @title, @date, @company, @accountTo, @accountFrom,
        ABS(@amount), @currency, @user, @creation::timestampz
      )
      RETURNING *
    `

    return this._execute({ sql, params })
  }

  private _execute (q: Query) {
    return this._connection.execute(q).catch((err: Error) => {
      throw new RepositoryError(err.message)
    })
  }
}
