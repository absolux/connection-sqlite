
import { RepositoryError } from './error'
import { Connection, Query } from '../types'

export interface CreateData {
  currency: string
  company: number
  account: number
  amount: number
  title: string
  user: number
  date: Date
}

export class ExpenseRepository {
  private _connection: Connection

  public constructor (db: Connection) {
    this._connection = db
  }

  public create (params: CreateData) {
    Object.assign(params, { creation: new Date() }) //.toISOString()

    let sql = `
      INSERT INTO payments (
        title, date, company_id, account_from, local_amount, 
        local_currency, creator_id, created_at
      )
      VALUES (
        @title, @date, @company, @account, ABS(@amount),
        @currency, @user, @creation
      )
      RETURNING *
    `

    return this._execute({ sql, params })
  }

  private _execute (q: Query) {
    return this._connection.execute(q).catch((err: Error) => {
      throw new RepositoryError(err.message)
    })
  }
}
